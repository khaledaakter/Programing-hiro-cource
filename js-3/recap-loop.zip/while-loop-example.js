var number = 1; // loop variable
// while (number <= 20) {
//     console.log(number);
//     number++;
// }

// odd numbers
// while (number <= 20) {
//     console.log(number);
//     number = number + 2;
// }

// even numbers
number = 0;
while (number <= 20) {
    console.log(number);
    number = number + 2;
}