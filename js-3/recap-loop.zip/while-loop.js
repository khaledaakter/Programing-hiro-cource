var roastGiven = 0;

while (roastGiven < 7) {
    console.log('Roast den, please!!');
    roastGiven++;
    console.log(roastGiven);
}