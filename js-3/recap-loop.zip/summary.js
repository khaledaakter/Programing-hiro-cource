// basic while loop
var i = 1;
while (i <= 7) {
    console.log(i);
    i++;
}
//basic for loop
for (var i = 1; i <= 7; i++) {
    console.log(i);
}