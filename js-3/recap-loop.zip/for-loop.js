// var roastGiven = 0;
// while(roastGiven < 7){
//     console.log('Roast den, please!');
//     roastGiven++;
// }

// console.log('running a for loop');
// for (var roastGiven = 0; roastGiven < 7; roastGiven++) {
//     console.log('Roast den, please!!');
//     console.log(roastGiven);
// }

for (var i = 1; i <= 10; i++) {
    console.log(i);
}

// odd 
// i+=2;
// i = i + 2
// for (var i = 1; i <= 20; i += 2) {
//     console.log(i);
// }

// even numbers
for (var i = 0; i <= 30; i += 2) {
    console.log(i);
}