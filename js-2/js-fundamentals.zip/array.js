var friendsAge = [11, 13, 17];

var muriChanacurFee = [34, 55, 221, 3];

var nayikas = ['mahi', "opu", "sabana", "kopila"];

var oddNumbers = [1, 3, 5, 7, 9];

var vowels = ['a', 'e', 'i', 'o', 'u'];

// console.log(nayikas.length);
var vowelsCount = vowels.length;
console.log(vowelsCount)