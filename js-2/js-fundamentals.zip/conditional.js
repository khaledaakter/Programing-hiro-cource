var isFoodReady = false;
// jodi food ready hoi taile ami khamu
// if food is ready i will eat
// if food is read == true
// if (condition) { 
//
// }
if (isFoodReady == true) {
    console.log('Mama!! I will eat now.')
}

var iphonePrice = 70000;
var myBudget = 109500;

// if (iphonePrice < myBudget) {
//     console.log('Iphone diya pic tule futani marbo!!')
// }

// if (iphonePrice > myBudget) {
//     console.log('My Shaomi is the best!!');
// }

// if (condition){
//     //
// }
// else{

// } 

var chickenPice = 180;
var myMoney = 850;

if (chickenPice < myMoney) {
    console.log('Yes! murgir Ran khamu ar haddi chabamu');
}
else {
    console.log('Smashed potato with Lentil soup')
}