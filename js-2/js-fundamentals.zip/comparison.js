// console.log(5 > 6);
// console.log(5 < 6);
// console.log(5 == 6);
// console.log(6 == 6);
// console.log(6 != 6);
var myLove = 99;
var yourLove = 100;

// console.log(myLove > yourLove);
// console.log(myLove == yourLove);
// console.log(myLove < yourLove);
// console.log(myLove != yourLove);

// console.log(studyGood && goodPerson);
// console.log(isBanker || goodResult);