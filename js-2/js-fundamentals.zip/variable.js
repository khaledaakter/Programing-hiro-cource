// Number
var watchPrice = 120;
watchPrice = 125;

// String
var userName = 'Sogir Uddin';

// Boolean
var isExpensive = true;
// Integer: 1 2 3 4 5 6 145
// Float 2.714 5.98745 3.14
// 2.7