// var price = 21;
// var age = 13;
// var temperature = 37;

// var name = 'sodur uddin';
// var address = "vooter goli kocu khet";
// var gf = "alia bhatt";
// var school = 'Ideal school and college';

// var pass = true;
// var subscribed = false;

var one = "40.12";
var next = "50.42";
var only = parseFloat(one);
var onlyn = parseFloat(next);

console.log((only + onlyn).toFixed(2));

