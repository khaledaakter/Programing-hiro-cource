var firstName = 'Jennie';
var lastName = 'Kim';
var fullName = firstName + ' ' + lastName;
// console.log(fullName);

var first = 'Ariana';
var last = 'Grande';
var name = first + ' ' + last;
// console.log(name);

var onionPrice = '42';
var eggPrice = '41';
var totalPrice = onionPrice + eggPrice;
// console.log(totalPrice);

// integer
var sunglass = 3;
//float
var price = 99.99;

var onionPrice = '42.50';
var eggPrice = '41.33';
var onionPriceNumber = parseFloat(onionPrice);
var eggPriceNumber = parseFloat(eggPrice);
// console.log(onionPriceNumber)
console.log(eggPriceNumber + onionPriceNumber);