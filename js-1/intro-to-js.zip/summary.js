// number
var eggPrice = 39;
eggPrice = 39 * 2;
console.log(eggPrice);
console.log(typeof eggPrice);

// string
var singer = 'Jennie Kim';

// boolean
var isHot = true;


