// recap
var price1 = 31;
var price2 = 10;
var sum = price1 + price2;
var difference = price2 - price1;
var multiplication = price1 * price2;
var division = price1 / price2;

// console.log(sum);
// console.log(difference);
// console.log(multiplication);
// console.log(division);

//
var doublePrice = price2 * 20;
// var newPrice = price1 + 10;
// price1 = price1 + 10;
price1 += 44;
// price2 = price2 - 2;
price2 -= 2;
// console.log(newPrice)
// console.log(price1)
// console.log(price2);

var age = 14;
age = age + 1;
age += 1;
age++;
console.log(age);

var love = 100;
love = love - 1;
love -= 1;
love--;
console.log(love);