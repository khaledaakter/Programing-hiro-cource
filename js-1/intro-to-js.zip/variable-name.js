var name = 'Hero Alan';

// reserved keyword not allowed
var false = 15;
var delete = 'delete';

// name should be one word
var nayok_name = 'Tom HANKS';

// quote is not allowed
var "nayika" = "shabnoor";

var my-office - address = 'andorkilla bandorban';
var my_office_address = 'andorkilla bandorban';
var myOfficeAddress = 'andorkilla bandorban';
var myofficeaddress = 'andorkilla bandorban';


var PIE = 3.14;

var 999price = 25;
var p45 = 96;

var userHomeAddress = 'katabon';
var uha = 'katabon';
