var tShirtPrice = 200;

var tShirtPrice2 = '200';

var isRaining = true;

var isRomantic;
// console.log(typeof tShirtPrice);
// console.log(typeof tShirtPrice2);
// console.log(typeof isRaining);
// console.log(typeof isRomantic);

// var today = new Date();
console.log(typeof today);